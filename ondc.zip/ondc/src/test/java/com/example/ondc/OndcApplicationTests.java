package com.example.ondc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OndcApplicationTests {

	@Test
	void contextLoads() {
	}

}
